# bootstrap-dropdown
The dropdown plugin from twitter bootstrap

For full documentation see http://twitter.github.com/bootstrap/javascript.html#dropdowns

This is a component.js compatible distribution of bootstrap-dropdown, automatically generated
from the latest twitter/bootstrap master (roughly) every 6 hours. It is part of the <a href="http://github.com/codemix/bootstrap-component">Bootstrap Component</a>
project.


Last build: v3.0.0 @ Tue Nov 19 2013 22:30:07 GMT+0000 (GMT)
