﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ILX.Portal.Web.Areas.Identity.IdentityExtension
{
	public class IdentityUser : Microsoft.AspNetCore.Identity.IdentityUser
	{
		public string FirstName { get; set; }

		public string LastName { get; set; }
	}
}
