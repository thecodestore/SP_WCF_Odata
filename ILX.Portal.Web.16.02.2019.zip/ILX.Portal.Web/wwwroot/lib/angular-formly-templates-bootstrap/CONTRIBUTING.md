# Contributing

See the instructions for contributing on the
[angular-formly core github repo](https://github.com/formly-js/angular-formly/blob/master/CONTRIBUTING.md)
