Ember Data
==========

Shim repository for the [Ember.js Data](http://github.com/emberjs/data) component.


Package Managers
----------------

* [Bower](http://bower.io): `ember-data`
* [Component](http://component.io): `components/ember-data`
* [Composer](http://packagist.org/packages/components/ember): `components/ember-data`
