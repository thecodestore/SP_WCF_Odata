ember-cli shims
===========

About
-----

ember-cli shims contain all the shims used in ember-cli.

License
-------

ember-cli shims is [MIT Licensed](https://github.com/stefanpenner/ember-cli-shims/blob/master/LICENSE.md).