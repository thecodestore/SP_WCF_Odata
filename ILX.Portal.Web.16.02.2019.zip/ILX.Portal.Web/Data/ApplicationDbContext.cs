﻿using System;
using System.Collections.Generic;
using System.Text;
using ILX.Portal.Web.Areas.Identity.IdentityExtension;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace ILX.Portal.Web.Data
{
	public class ApplicationDbContext : IdentityDbContext<ILX.Portal.Web.Areas.Identity.IdentityExtension.IdentityUser>
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
			: base(options)
		{
		}
	}
}
