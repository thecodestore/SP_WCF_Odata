Ember load initializers
===========

About
-----

Ember loadInitializers is a tiny package to autoload your initializer files in EAK and ember-cli.

License
-------

Ember loadInitializers is [MIT Licensed](https://github.com/ember-cli/ember-load-initializers/blob/master/LICENSE.md).
